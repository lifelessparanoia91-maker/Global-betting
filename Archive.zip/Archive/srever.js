const express = require('express');
const http = require('http');
const WebSocket = require('ws');
const crypto = require('crypto');
const path = require('path');

const app = express();
const server = http.createServer(app);
const wss = new WebSocket.Server({ server });

app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

// Mock In-Memory Databases (Use PostgreSQL / Redis in production)
let users = {
  "user_101": { id: "user_101", username: "Webster", balance: 500.00 }
};

let processedTransactions = new Set();

let liveOdds = {
  eventId: "EVT_9021",
  homeTeam: "Arsenal",
  awayTeam: "Chelsea",
  markets: {
    homeWin: 2.10,
    draw: 3.40,
    awayWin: 3.20
  }
};

// ==========================================
// 1. WEBSOCKET ENGINE (Live Odds Updates)
// ==========================================
wss.on('connection', (ws) => {
  console.log('Client connected to live odds feed.');
  
  // Send initial odds on connection
  ws.send(JSON.stringify({ type: 'ODDS_UPDATE', data: liveOdds }));

  ws.on('close', () => console.log('Client disconnected.'));
});

// Broadcast live odds to all connected clients
function broadcastOdds() {
  wss.clients.forEach((client) => {
    if (client.readyState === WebSocket.OPEN) {
      client.send(JSON.stringify({ type: 'ODDS_UPDATE', data: liveOdds }));
    }
  });
}

// Simulate market fluctuation every 5 seconds
setInterval(() => {
  const shift = (Math.random() * 0.10 - 0.05).toFixed(2);
  liveOdds.markets.homeWin = Math.max(1.05, parseFloat((liveOdds.markets.homeWin + parseFloat(shift)).toFixed(2)));
  broadcastOdds();
}, 5000);

// ==========================================
// 2. BET PLACEMENT API
// ==========================================
app.post('/api/v1/bet/place', (req, res) => {
  const { userId, eventId, outcome, selectedOdds, stake } = req.body;

  const user = users[userId];
  if (!user) {
    return res.status(404).json({ success: false, message: 'User not found' });
  }

  if (user.balance < stake) {
    return res.status(400).json({ success: false, message: 'Insufficient funds' });
  }

  // Verify live odds state
  const currentOdds = liveOdds.markets[outcome];
  if (!currentOdds || Math.abs(currentOdds - selectedOdds) > 0.05) {
    return res.status(409).json({ 
      success: false, 
      message: 'Odds updated during placement. Please accept new odds.',
      currentOdds 
    });
  }

  // Deduct stake from user balance
  user.balance -= stake;

  return res.json({
    success: true,
    message: 'Bet placed successfully',
    newBalance: user.balance,
    betTicket: {
      ticketId: 'TKT_' + Date.now(),
      eventId,
      outcome,
      odds: currentOdds,
      stake,
      potentialPayout: (stake * currentOdds).toFixed(2)
    }
  });
});

// ==========================================
// 3. PAYMENT WEBHOOK API (Deposits)
// ==========================================
const PAYMENT_SECRET_KEY = "my_super_secret_webhook_key";

app.post('/api/v1/payments/webhook', (req, res) => {
  const signature = req.headers['x-signature'];
  const { transactionId, userId, amount, status } = req.body;

  // Verify HMAC signature
  const expectedSignature = crypto
    .createHmac('sha256', PAYMENT_SECRET_KEY)
    .update(JSON.stringify(req.body))
    .digest('hex');

  if (signature !== expectedSignature) {
    return res.status(401).json({ success: false, message: 'Invalid signature' });
  }

  // Check idempotency (prevent double processing)
  if (processedTransactions.has(transactionId)) {
    return res.status(200).json({ success: true, message: 'Transaction already processed' });
  }

  if (status === 'COMPLETED') {
    if (users[userId]) {
      users[userId].balance += parseFloat(amount);
    }
    processedTransactions.add(transactionId);
  }

  return res.status(200).json({ success: true, message: 'Deposit processed' });
});

// Helper route to check user balance
app.get('/api/v1/user/:id', (req, res) => {
  const user = users[req.params.id];
  if (!user) return res.status(404).json({ message: 'User not found' });
  res.json(user);
});

const PORT = process.env.PORT || 3000;
server.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
